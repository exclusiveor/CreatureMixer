﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : Singleton<GameManager>
{
    // guarantee this will be always a singleton only - can't use the constructor!
    protected GameManager() {
        
    }

    public PlayerSettings Settings;
    public AtlasFramesCache AtlasFramesCache;
    public GameData GameData;
    public GameFlow GameFlow;
	public EventManager EventManager;
    public ZStat ServerStatistic;
    public FacebookIntegration Facebook;
	public bool allowQuit;
	public bool isNeedReminder;
	public MatchBoard Board;

    public UserData Player
    {
        get
        {
            return Settings.User;
        }
    }
    
    public void Initialize()
    {
        Input.multiTouchEnabled = false;
        Localer.Init();
		CreatePauseListener();
        GameData = new GameData();        
        Settings = new PlayerSettings();
        AtlasFramesCache = new AtlasFramesCache();
        GameFlow = new GameFlow();
		EventManager = new EventManager();
        ServerStatistic = new ZStat();        
        Facebook = gameObject.AddComponent<FacebookIntegration>();
        GameManager.Instance.Facebook.Init();
    }

	private void CreatePauseListener()
	{
		#if UNITY_STANDALONE

		#else
		
		#endif
	}

    new public void OnDestroy()
    {        
        base.OnDestroy();
    }

    public void Load()
    {        
        // first load all constant data from XML's
        GameData.Load();
        // next load writable user data from PlayerPrefs
        Settings.Load();

		if (Instance.Settings.GetUpgradeProgress("Casino") >= 0) {
			Settings.User.ShowReminderOnExit = !Settings.User.ShowReminderOnExit;
			isNeedReminder = Settings.User.ShowReminderOnExit;
		} else {
			Settings.User.ShowReminderOnExit = false;
			isNeedReminder = false;
		}
	}


	public void TryApplicationQuit() {
		if (isNeedReminder) {
			Application.CancelQuit();
			isNeedReminder = false;
			EventData eventData = new EventData("OnOpenFormNeededEvent");
			eventData.Data["form"] = UIConsts.FORM_ID.CONFIRM_WINDOW;
			eventData.Data["type"] = "confirm_exitreminder";
			eventData.Data["parameter"] = "";
			GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
		} else {
			Instance.GameFlow.ExitGame();
		}
	}

	void OnApplicationQuit() {
		if (Instance.Settings.User.DontShowExitGameWindow || allowQuit) {
			TryApplicationQuit();
		} else {
			Application.CancelQuit();
			EventData eventData = new EventData("OnOpenFormNeededEvent");
//			if (GameFlow.CurrentActiveWindowId == UIConsts.FORM_ID.MATCH3_MAIN_MENU && !Player.LastLevelWinTrigger) //TODO
//			{
//				eventData.Data["form"] = UIConsts.FORM_ID.CONFIRM_WINDOW;
//				eventData.Data["type"] = "confirm_quit";
//				eventData.Data["parameter"] = "exit";
//			} else
			{
				eventData.Data["form"] = UIConsts.FORM_ID.EXIT_GAME_WINDOW;
			}
			GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
		}
	}

	public void HideTutorial(string id = "")
	{
		if (GameManager.Instance.GameFlow.IsSomeWindow() && GameFlow.CurrentActiveWindowId == UIConsts.FORM_ID.TUTOR)
		{
			EventData eventData = new EventData("OnOpenFormNeededEvent");
			eventData.Data["form"] = UIConsts.FORM_ID.TUTOR;
			eventData.Data["id"] = id;
			eventData.Data["hide"] = true;
			GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
		}
	}

	public void ShowTutorial(string id, bool exclusive = false)
	{
		if (GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MAP && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3 && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3_CHALLANGE)
		{
			return;
		}
		// variant for old tutorials
		//EventData eventData = new EventData("OnTutorialNeededEvent");
		//eventData.Data["id"] = id;
		//GameManager.Instance.EventManager.CallOnTutorialNeededEvent(eventData);

		if (GameManager.Instance.GameFlow.IsSomeWindow() && GameFlow.CurrentActiveWindowId != UIConsts.FORM_ID.TUTOR)
		{
			// cant show tutorial (some window is opened)
			// TODO try open after delay? no!
			return;
		}

		// variant for new Tutors
		EventData eventData = new EventData("OnOpenFormNeededEvent");
		eventData.Data["form"] = UIConsts.FORM_ID.TUTOR;
		eventData.Data["id"] = id;
		eventData.Data["toqueue"] = GameManager.Instance.GameFlow.IsSomeWindow();
		eventData.Data["exclusive"] = exclusive;
		GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
	}

	public void ShowTutorialOnTopOfWindow(string id)
	{
		if (GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MAP && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3 && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3_CHALLANGE)
		{
			return;
		}
		if (GameManager.Instance.GameFlow.IsSomeWindow() && GameFlow.CurrentActiveWindowId != UIConsts.FORM_ID.TUTOR)
		{
			//BaseUIController buic = GameFlow.CurrentActiveWindow.GetComponent<BaseUIController>();
			//buic.TemporaryDisabled = true;
			//_disabledWindow = GameFlow.CurrentActiveWindowId;
			GameManager.Instance.GameFlow.ClearCurrentWindow();
		}
		
		// variant for new Tutors
		EventData eventData = new EventData("OnOpenFormNeededEvent");
		eventData.Data["form"] = UIConsts.FORM_ID.TUTOR;
		eventData.Data["id"] = id;
		eventData.Data["toqueue"] = GameManager.Instance.GameFlow.IsSomeWindow();
		eventData.Data["exclusive"] = true;
		GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
	}

	public void ShowTutorialDelayed(string id, float delay, bool exclusive = false)
	{
		if (GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MAP && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3 && GameFlow.GetCurrentScene() != UIConsts.SCENE_ID.MATCH3_CHALLANGE)
		{
			return;
		}
		LeanTween.delayedCall(gameObject, delay, ()=>{ ShowTutorial(id); });
	}

	public void TryShowTutorFromQueue()
	{
		ShowTutorial("");
	}

	public void CallHorseSelection()
	{
		Invoke("CallHorsesWindow", MapConsts.MAP_MOVE_TIME);
	}

	private void CallHorsesWindow()
	{
		EventData eventData = new EventData("OnOpenFormNeededEvent");
		eventData.Data["form"] = UIConsts.FORM_ID.HORSE_SELECTION;
		//eventData.Data["parameter"] = "...";
		GameManager.Instance.EventManager.CallOnOpenFormNeededEvent(eventData);
	}

	void OnApplicationFocus(bool focusStatus) 
	{
		#if UNITY_STANDALONE
		if (GameManager.Instance.Player.Fullscreen)
		{
			AudioListener.pause = !focusStatus;
		} else
		{
			AudioListener.pause = false;
		}
		#else
		
		#endif
		
	}

//	void OnGUI()
//	{
//		GUI.DrawTexture (new Rect(Event.current.mousePosition.x-64, Event.current.mousePosition.y-64, 128, 128), GameManager.Instance.Settings.AvailableCursors["custom_cursor_0"].Texture);
//	}

}